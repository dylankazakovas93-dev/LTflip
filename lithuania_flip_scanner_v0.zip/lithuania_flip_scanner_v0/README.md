# Lithuania Flip Scanner v0.1

This is a **high-spread resale-arbitrage decision engine**.

It does not auto-buy anything. It takes candidate listings and decides whether they are worth inspecting in person.

## Your agreed thresholds

Default rules:

- Minimum expected **net profit**: €100
- Minimum **net ROI** after all costs: 60%
- Minimum gross spread before costs: 100%
- Prefer Vilnius/Kaunas pickup
- Reject broken / repair / unknown-condition listings

## Why decision engine first?

A live scraper is not the main edge yet. The main edge is avoiding trash.

The correct workflow is:

1. Collect candidate local listings manually or via permitted exports/alerts.
2. Enter the listing and conservative eBay sold-comp numbers into `input_template.csv`.
3. Run scanner.
4. Only inspect `PRIORITY_INSPECT` and `INSPECT` listings.
5. Never buy without in-person testing.

## Run

```bash
python3 listing_scanner.py example_listings.csv --config config.json --output scan_results.csv
```

Then open `scan_results.csv`.

## Input columns

- `url`: listing link
- `category`: `lens`, `music_gear`, `lego_collectible`, or `general`
- `title`: local listing title
- `description`: local listing description
- `location`: city
- `asking_price_eur`: local price
- `comp_low_eur`: conservative eBay sold-comp price
- `comp_median_eur`: median eBay sold-comp price
- `liquidity_sold_count`: number of recent sold comps
- `platform_fee_pct`: example `0.13` for 13%
- `risk_reserve_pct`: default 10% of resale price
- `buy_transport_cost_eur`: pickup travel cost
- `resale_shipping_cost_eur`: cost to ship to buyer
- `packaging_cost_eur`: box/bubble wrap/etc.
- `misc_cost_eur`: any extra cost
- `can_inspect_in_person`: `yes` or `no`
- `photo_quality`: `good`, `medium`, or `poor`

## Decision meanings

- `PRIORITY_INSPECT`: strongest opportunity. Inspect quickly.
- `INSPECT`: passes math and condition filters.
- `WATCHLIST`: not rejected, but not strong enough.
- `PASS`: fails hard rules.

## Important compliance note

Respect marketplace terms, robots.txt, and privacy rules. Do not bypass login, rate limits, CAPTCHAs, or scrape personal/contact data. This v0 is built as a manual/CSV decision engine so you can validate the economics before automating collection.
